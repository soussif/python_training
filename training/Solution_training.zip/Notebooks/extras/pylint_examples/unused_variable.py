"""Example of pylint warning W0612 (unused variable)"""

def unused_variable():
    """We define two variable here but only ever use one of them"""
    unused = 5
    used = 10
    return used * 2
