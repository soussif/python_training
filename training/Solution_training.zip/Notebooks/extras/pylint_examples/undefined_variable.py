"""Example of pylint error E0602 (undefined variable) and warning W0612 (unused variable)"""

def undefined_variable():
    """This function contains an error where there's a variable `Number` instead of `number`"""
    Number = 5 # Accidental capital
    return number * 2 # NameError: name 'number' is not defined
