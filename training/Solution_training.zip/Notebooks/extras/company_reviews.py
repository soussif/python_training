from flask_sqlalchemy import SQLAlchemy

from flask import Flask, request, render_template

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///forbes.sqlite'
db = SQLAlchemy(app)

class Company(db.Model):
    __tablename__ = 'companies'
    id = db.Column(db.Integer, primary_key=True)
    rank = db.Column(db.Integer)
    name = db.Column(db.Text)
    country = db.Column(db.Text)
    sales = db.Column(db.Float)
    profits = db.Column(db.Float)
    assets = db.Column(db.Float)
    marketvalue = db.Column(db.Float)
    # rank,name,country,sales,profits,assets,marketvalue

class Review(db.Model):
    __tablename__ = 'reviews'
    id = db.Column(db.Integer, primary_key=True)
    rating = db.Column(db.Integer)
    company_id = db.Column(db.Integer, db.ForeignKey('companies.id'), nullable=False)
    company = db.relationship(Company, backref=db.backref('reviews', lazy='joined'))
    
db.create_all()   

def populate_companies_table():
    import pandas as pd
    forbes = pd.read_csv('/data/forbes1964.csv')
    for row in forbes.itertuples():
        company = Company(rank=row.rank,
                          name=row.name,
                          country=row.country,
                          sales=row.sales,
                          profits=row.profits,
                          assets=row.assets,
                          marketvalue=row.marketvalue)
        db.session.add(company)
    db.session.commit()

populate_companies_table()

@app.route('/add_review', methods=['POST'])
def add_review():
    rating = request.form['rating']
    company = request.form['company']
    review = Review(company=company, rating=rating)
    db.session.add(review)
    db.session.commit()
    
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/show')
def show():
    company = request.form['company']
    reviews = db.session.query.filter(company==company)
    #ratings = [review.rating for review in reviews]
    return render_template('show_reviews.html', reviews=reviews)
