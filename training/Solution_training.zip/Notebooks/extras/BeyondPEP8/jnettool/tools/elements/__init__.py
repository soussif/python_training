"""
Mock-up of code for a routing table etc.
"""

from typing import List

from .. import Route, RoutingTable


class NetworkElement:
    def __init__(self, ip_address):
        print(f'Creating NetworkElement({ip_address})')
        self.ip_address = ip_address
        route1 = Route('route1', '25.21.1.6')
        route2 = Route('route2', '25.21.1.7')
        self.routing_table = RoutingTable([route1, route2])
        self.messages = []

    def getRoutingTable(self):
        return self.routing_table

    def cleanup(self, message):
        self.messages.append(message)
        print('Messages:', *self.messages)

    def disconnect(self):
        print('Disconnecting ...')


class MissingVar(ValueError):
    """Scary exception"""

