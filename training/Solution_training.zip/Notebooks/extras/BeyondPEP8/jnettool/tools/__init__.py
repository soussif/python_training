from typing import List


class RouteInspector:
    pass

class Route:
    def __init__(self, name, ip_address):
        self.name = name
        self.ip_address = ip_address

    def getName(self):
        return self.name

    def getIPAddr(self):
        return self.ip_address


class RoutingTable(list):
    def __init__(self, routes: List[Route] = None):
        if routes:
            self.extend(routes)

    def addRoute(self, route: Route):
        self.append(route)

    def getRouteByIndex(self, index: int) -> Route:
        return self[index]

    def getSize(self):
        return len(self)



