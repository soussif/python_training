import time

import cv2


cam = cv2.VideoCapture(0)
time.sleep(0.5)

s, img = cam.read()
if s:
    cv2.imwrite("extras/captured.jpg", img)

cam.release()
