"""
Scrape the complete list of stock symbols from the EODData website.

This includes parsing the output to something more useful, and then dumping
somewhere safe.
"""
import csv

import scrapy


class StockItem(scrapy.Item):
    symbol = scrapy.Field()
    description = scrapy.Field()
    exchange_name = scrapy.Field()


class EODDataSpider(scrapy.Spider):

    name = 'EODData_spider'

    start_urls = ['http://www.eoddata.com/symbols.aspx']

    def parse(self, response):
        """
        The original parse method to be called.

        In this case all it should do is perform the login and then pass across
        to the after_login to get all the symbol IDs.
        """
        self.logger.info('Starting the scrape')
        return scrapy.FormRequest.from_response(
            response,
            formid='aspnetForm',
            formdata={
                # 'ctl00_cph1_ls1_txtEmail': 'henrywalshaw',  # username field
                # 'ctl00_cph1_ls1_txtPassword': '[7k7PKdC,zLj#F9e'  # pswd
                'ctl00_tsm_HiddenField': '',
                '__EVENTTARGET': '',
                '__EVENTARGUMENT': '',
                '__LASTFOCUS': '',
                '__VIEWSTATE': '/wEPDwUKLTU5MTQwNTQ4Nw9kFgJmD2QWAgIDD2QWAgIHD2QWBgIBDxAPFgYeDkRhdGFWYWx1ZUZpZWxkBQRDb2RlHg1EYXRhVGV4dEZpZWxkBQROYW1lHgtfIURhdGFCb3VuZGdkEBUYF0FtZXJpY2FuIFN0b2NrIEV4Y2hhbmdlHkF1c3RyYWxpYW4gU2VjdXJpdGllcyBFeGNoYW5nZRZDaGljYWdvIEJvYXJkIG9mIFRyYWRlGENoaWNhZ28gRnV0dXJlcyBFeGNoYW5nZRxDaGljYWdvIE1lcmNoYW50aWxlIEV4Y2hhbmdlG05ldyBZb3JrIENvbW1vZGl0eSBFeGNoYW5nZRZFVVJFWCBGdXR1cmVzIEV4Y2hhbmdlEEZvcmVpZ24gRXhjaGFuZ2UYSG9uZyBLb25nIFN0b2NrIEV4Y2hhbmdlDkdsb2JhbCBJbmRpY2VzGkthbnNhcyBDaXR5IEJvYXJkIG9mIFRyYWRlGUxJRkZFIEZ1dHVyZXMgYW5kIE9wdGlvbnMVTG9uZG9uIFN0b2NrIEV4Y2hhbmdlGk1pbm5lYXBvbGlzIEdyYWluIEV4Y2hhbmdlFU5BU0RBUSBTdG9jayBFeGNoYW5nZRdOZXcgWW9yayBCb2FyZCBvZiBUcmFkZR1OZXcgWW9yayBNZXJjaGFudGlsZSBFeGNoYW5nZRdOZXcgWW9yayBTdG9jayBFeGNoYW5nZRJPVEMgQnVsbGV0aW4gQm9hcmQYU2luZ2Fwb3JlIFN0b2NrIEV4Y2hhbmdlFlRvcm9udG8gU3RvY2sgRXhjaGFuZ2UYVG9yb250byBWZW50dXJlIEV4Y2hhbmdlDE11dHVhbCBGdW5kcxtXaW5uaXBlZyBDb21tb2RpdHkgRXhjaGFuZ2UVGARBTUVYA0FTWARDQk9UA0NGRQNDTUUFQ09NRVgFRVVSRVgFRk9SRVgESEtFWAVJTkRFWARLQ0JUBUxJRkZFA0xTRQRNR0VYBk5BU0RBUQVOWUJPVAVOWU1FWAROWVNFBU9UQ0JCA1NHWANUU1gEVFNYVgRVU01GA1dDRRQrAxhnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dkZAIJD2QWBAIDD2QWAgIHDw8WAh4EVGV4dGVkZAIHDw8WAh4HVmlzaWJsZWhkZAILD2QWBAIBDw8WAh8DBQwyNy4zMy4xMDQuNTRkZAIDDw8WAh8DZWRkGAEFHl9fQ29udHJvbHNSZXF1aXJlUG9zdEJhY2tLZXlfXxYBBRpjdGwwMCRjcGgxJGxzMSRjaGtSZW1lbWJlcl4ScviNn9hWjZStC2/fzNuG4wbt26fB4SV5rThPkO7A',
                '__VIEWSTATEGENERATOR': '375F2A43',
                '__EVENTVALIDATION': '/wEdACHkcZ+SMgK4x5rWK9EnPL3Vx+CzKn9gssNaJswg1PWksJd223BvmKj73tdq9M98Zo0ieOST2uRTGot0U1lYmiLnnhPrM74Ub5O/MENwdV3PghYeNGKJVpBziHAzYafHxwNre+fg6ROJ8j65uzV6mUfMOXXizkhQ5wkRIBmIfC425vSlzrSu/KQkYuu90H6P+dMEKN117FJYPAv2nIksfORkElVjD7tvzk5V7F48bpuIAvxwbqzprGXsvVBUHIG/E8bTjLemWBd8FXuoSS+cWvlcJB27FeoN7qlZbvjeZ2g22e27kEF7Er/D0dItmgw6c8/P6gA508D6bOPepxL/kw9kialJLXTbcUaCcY/VkEogUG8zjO/ZoZvUy6CDlpZwgIBSNrXvFeRwP7WydkS1/n9oiXsWvHUGwO9CJ8SP6jLC5YmocYUdiab7mfJPsIrqy2b5yjlgmWbyTeVaIVYlAxa8IwkIEMN/BVC7I85+YgaH0SXajLdx+PewuUtozoGZxCY/saJjIn5Bvd6+kGiOqz890niKP0b8/qxWZmJUbC/OmXVxDafud/tH+Oofr/xKPFs3mMw0mUR42jY0I1vrw21NZ8NL/rT3wRURaUhs7EWQR2qKVna4BwNWZXJp9pcSxVyNqITYFrAsqMpk0JNxp9M4c0xJA4aEsobaXQNzN6Jx7hoeaSpaeSX6r42nzFWNsseyAhCPGqPY7Tmtp5frWbeisxDdk8ciZHYJqjc+1jbFcw==',
                'ctl00$Menu1$s1$txtSearch': '',
                'ctl00$cph1$cboExchange': 'NYSE',
                'ctl00$cph1$ls1$txtEmail': 'henrywalshaw',
                'ctl00$cph1$ls1$txtPassword': '[7k7PKdC,zLj#F9e',
                'ctl00$cph1$ls1$btnLogin': 'Login',
                # form button: ctl00_cph1_ls1_btnLogin
            },
            clickdata={'id': 'ctl00_cph1_ls1_btnLogin'},
            callback=self.after_login
        )

    def after_login(self, response):
        """
        Find all the stock exchange symbol IDs and download all the data
        """
        self.logger.debug('check login succeed before going on')
        login_name = response.xpath(
            '//span[@id="ctl00_cph1_ls1_lblName"]/text()').extract_first()
        if login_name != 'Henry Walshaw':
            self.logger.error("Login failed")
            self.logger.error(str(login_name))
            return

        self.logger.info('Login (hopefully) succeeded')
        yield response.follow(
            self.start_urls[0], callback=self.back_to_symbols)

    def back_to_symbols(self, response):
        """
        At this point grab the list of Stock Exchange IDs and download the
        data there individually, from
        http://www.eoddata.com/Data/symbollist.aspx?e=NYSE
        """
        self.logger.info('Looking for symbols')
        for dropdown in response.xpath(
                '//select[@id="ctl00_cph1_cboExchange"]/option'):
            symbol = dropdown.xpath('@value').extract_first()
            name = dropdown.xpath('text()').extract_first()

            request = scrapy.Request(
                f'https://www.eoddata.com/Data/symbollist.aspx?e={symbol}',
                callback=self.parse_stocklists
            )
            request.meta['name'] = name
            yield request

    def parse_stocklists(self, response):
        """
        Grab the individual data pages and parse them
        """
        self.logger.info(f"Extracting data for {response.url}")

        for row in csv.DictReader(response.text.split('\n'), delimiter='\t'):
            # self.logger.debug(str(row))
            item = StockItem(
                symbol=row['Symbol'],
                description=row['Description'],
                exchange_name=response.meta.get('name')
            )
            yield item
