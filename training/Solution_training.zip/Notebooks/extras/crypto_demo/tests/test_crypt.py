from secure.crypt import encrypt, decrypt

reference_key = b'lCbzeQhmyf0AHVc8dvM3MCm8kOWFM3m1lHm_zu_KDDc='
plaintext = b'hello world'


def test_ciphertext():
    ciphertext = encrypt(plaintext, reference_key)
    assert len(ciphertext) > len(plaintext)


def test_roundtrip():
    k = reference_key
    assert decrypt(encrypt(plaintext, k), k) == plaintext
