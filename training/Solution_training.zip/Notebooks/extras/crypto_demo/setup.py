from setuptools import setup

setup(
    name = "crypto_demo",
    version = "0.1",
    author = "Python Charmers",
    author_email = "info@pythoncharmers.com",
    description = "A sample app showing how to write and run unit tests",
    packages=['secure', 'tests'],
)
