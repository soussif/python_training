from cryptography.fernet import Fernet


def random_key():
    return Fernet.generate_key()

def encrypt(text_bytes, key):
    cipher = Fernet(key)
    ciphertext = cipher.encrypt(text_bytes)
    return ciphertext

def decrypt(ciphertext, key):
    cipher = Fernet(key)
    plaintext_bytes = cipher.decrypt(ciphertext)
    return plaintext_bytes

