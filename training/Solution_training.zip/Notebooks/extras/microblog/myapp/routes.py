from flask import render_template, flash, redirect
from myapp import app
from myapp.forms import LoginForm

@app.route('/')
@app.route('/index')
def index():
#    return 'Hello world!'
    return render_template('index.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        flash(f'Logged in user {form.username.data}!')
        return redirect('/index')
    else:
        return render_template('login.html', title='Sign In', form=form)
