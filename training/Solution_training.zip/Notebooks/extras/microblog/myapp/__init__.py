from flask import Flask
from flask_bootstrap import Bootstrap
from config import Config

app = Flask(__name__)
Bootstrap(app)
app.config.from_object(Config)
#app.config['DEBUG'] = True
#app.config['PORT'] = 5001
print(app.config)

from myapp import routes