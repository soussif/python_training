"""A Python Program to fetch a series of online articles and generate an HTML report of their contents.

To run the newster program on the command line:

python newster.py
"""

from newspaper import Article
from jinja2 import Template


def process_url(url):
    """Fetch an  Article URL and extract data from the page"""
    print(f"processing: {url}")
    article = Article(url)
    article.download()
    article.parse()
    return {
        "url": article.url,
        "title": article.title,
        "date": article.publish_date.strftime("%d-%m-%Y"),
        "img_url": article.top_image,
        "authors": article.authors,
    }


def make_report_html(articles):
    template = Template(
        """
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <title>{{ title }}</title>
        <style>
          .article {
              margin: 1em;
              padding: 0.5em;
              width: 700px;
              border-radius: 10px;
              border: solid black;
              box-shadow: 2px 2px -1px 0px black;
          }
          .article img {width:300px}
          .article h2 {margin-top: 0em}
          .article a {
              color: black;
              text-decoration: none;
          }
          .bold {font-weight: 600}
        </style>
        </head>
    <body>
      <h1>{{ title }}</h1>

        {% for article in articles %}
          <div class="article">
            <h2><a href="{{ article.url }}">{{ article.title }}</a></h3>
            <p><span class="bold">Published:</span> {{ article.date }}</p>
            <p><span class="bold">Authors</span>: {{ ", ".join(article.authors) }}</p>
            <img src="{{ article.img_url }}">
          </div>
        {% endfor %}

    </body>
    </html>
       """
    )
    return Template.render(title="Article Report", articles=articles)


def generate_report(urls, output_path):
    """Create an HTML report for a newspaper and write it to a file"""
    print("Generating the report")
    articles = [process_url(url) for url in urls]
    report_html = make_report_html(articles)

    with open(output_path, "wt", encoding="utf8") as file:
        file.write(report_html)

    print(f"Wrote report to {output_path} with {len(articles)} articles.")


def main():
    """Command line entry point for the Newster tool"""
    with open("urls.txt") as urls_file:
        urls = urls_file.read().splitlines()

    generate_report(urls, "report.html")

    
if __name__ == "__main__":
    main()
