from setuptools import setup, find_packages

setup(
    name="newster",
    version="0.0.1",
    description="Tool for creating article reports",
    author="Me",
    author_email="me@team.telstra.com",
    packages=find_packages("src"),
    package_dir={"": "src"},
    install_requires=["newspaper3k", "jinja2", "click"],
    entry_points={"console_scripts": ["newster=newster.cli:run"]},
)
