from jinja2 import Template


def make_report_html(articles):
    """Create the HTML for the report from a sequence of articles"""
    template = Template(
        """
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <title>{{ title }}</title>
        <style>
          .article {
              margin: 1em;
              padding: 0.5em;
              width: 700px;
              border-radius: 10px;
              border: solid black;
              box-shadow: 2px 2px -1px 0px black;
          }
          .article img {width:300px}
          .article h2 {margin-top: 0em}
          .article a {
              color: black;
              text-decoration: none;
          }
          .bold {font-weight: 600}
        </style>
        </head>
    <body>
      <h1>{{ title }}</h1>

        {% for article in articles %}
          <div class="article">
            <h2><a href="{{ article.url }}">{{ article.title }}</a></h3>
            <p><span class="bold">Published:</span> {{ article.date }}</p>
            <p><span class="bold">Authors</span>: {{ ", ".join(article.authors) }}</p>
            <img src="{{ article.img_url }}">
          </div>
        {% endfor %}

    </body>
    </html>
       """
    )
    return template.render(title="Article Report", articles=articles)
