import click

from .news import generate_report


@click.command()
@click.argument("urls_path")
@click.option(
    "--output-path", default="report.html", help="The output report file path."
)
def run(urls_path, output_path):
    """Simple program that greets NAME for a total of COUNT times."""
    with open(urls_path) as urls_file:
        urls = urls_file.read().splitlines()

    generate_report(urls, output_path)
