"""A Python Program to fetch a series of online articles and generate an HTML
report of their contents"""

from newspaper import Article, ArticleException

from .utils import make_logger
from .make_html import make_report_html


logger = make_logger()


def process_url(url):
    """Fetch an article URL and extract data from the page"""
    logger.debug(f"Processing URL: {url}")
    article = Article(url)
    article.download()
    article.parse()
    return {
        "url": article.url,
        "title": article.title,
        "date": article.publish_date.strftime("%d-%m-%Y"),
        "img_url": article.top_image,
        "authors": article.authors,
    }


def generate_report(urls, output_path):
    """Create an HTML report for a newspaper and write it to a file"""
    logger.debug("Generating the report")

    articles = []
    for url in urls:
        try:
            article = process_url(url)
            articles.append(article)
        except ArticleException as error:
            logger.error(error)

    report_html = make_report_html(articles)

    with open(output_path, "wt") as output_file:
        output_file.write(report_html)

    logger.info(f"Wrote report to {output_path} with {len(articles)} articles.")

