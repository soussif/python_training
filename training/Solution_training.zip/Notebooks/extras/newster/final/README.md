Newster is a package for creating a basic HTML report of series of online
news articles. 

The package has the following third-party dependencies:
- [Newspaper3k](https://newspaper.readthedocs.io)
- [Jinja2](https://jinja.palletsprojects.com)
- [Click](https://click.palletsprojects.com)

To install newster:

    $ pip install -e .
    
To run on the command line:

    $ newster URLS_FILE
    
Where `URLS_FILE` is the path to a file containing the article URLs to be
scraped, with one URL on each line. This will create an HTML report in
`report.html`.
