from newster.news import generate_report


def test_report(tmp_path):
    url = "https://www.theguardian.com/us-news/2019/oct/16/democrats-pelosi-meltdown-trump-meeting"
    output_path = tmp_path / "report.html"
    generate_report([url], output_path)
    assert output_path.is_file()
    assert output_path.stat().st_size > 0
