from collections import Counter
import gzip
from io import BytesIO
import json
import os.path
import re
import string

import environs
from flask import Flask, jsonify, request, send_file
import wordcloud


app = Flask(__name__)
env = environs.Env()

data_dir = env('DEFAULT_PATH')
default_path = os.path.join(data_dir, 'alice_in_wonderland.txt.gz')


def count_words(text, language):
    words = re.sub(
        f'[{string.punctuation}]',
        '',
        text
    ).lower().split()

    frequencies = dict(Counter(words))
    stopwords = set(json.load(
        open(os.path.join(data_dir, 'stopwords-iso.json'))
    )[language])
    uncommon_frequencies = {
        k: frequencies[k]
        for k in filter(lambda w: w not in stopwords, frequencies)
    }
    return uncommon_frequencies


@app.route('/wordcount', methods=['POST', 'GET'])
def wordcount():

    f = request.files.get('document')
    if not f:
        f = gzip.open(default_path)

    text = f.read().decode('utf-8')
    language = request.form.get('language', 'en').lower()  # ensures language code is lower case

    uncommon_frequencies = count_words(text, language)

    return jsonify(dict(Counter(uncommon_frequencies).most_common(10)))


@app.route('/', methods=['POST', 'GET'])
def wordcount_image():

    f = request.files.get('document')
    if not f:
        f = gzip.open(default_path)

    text = f.read().decode('utf-8')
    language = request.form.get('language', 'en').lower()  # ensures language code is lower case

    uncommon_frequencies = count_words(text, language)
    cloud = wordcloud.WordCloud(background_color='white')
    image = cloud.generate_from_frequencies(uncommon_frequencies).to_image()

    placeholder = BytesIO()
    image.save(placeholder, 'png')
    placeholder.seek(0)

    return send_file(placeholder, 'image/png')


if __name__ == '__main__':
    app.run()
