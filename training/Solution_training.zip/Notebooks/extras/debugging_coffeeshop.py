import json

from flask import Flask, render_template_string

template = """
<h1>{{ name }}</h1>
<h2>Rating: {{ rating }} of 5</h2>
{% for review in reviews %}
<p>{{ review.text}} <em>{{ review.author }}</em></p>
{% endfor %}
"""
coffeeshop_data = json.load(open('coffeeshop.json'))

app = Flask(__name__)

@app.route("/<coffeeshop_id>")
def coffeeshop(coffeeshop_id):
    coffeeshop = coffeeshop_data['coffeeshop'][coffeeshop_id]
    reviews = coffeeshop_data['reviews'][coffeeshop_id]
    
    rating = sum([r['rating'] for r in reviews]) / len(reviews)
    
    return render_template_string(template, name=coffeeshop['name'], rating=rating, reviews=reviews)
    
if __name__ == '__main__':
    app.run()
