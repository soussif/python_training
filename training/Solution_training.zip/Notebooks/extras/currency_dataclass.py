from dataclasses import dataclass

import requests

@dataclass
class Currency:
    name: str
    central_bank: str
    symbol: str
    code: str = 'AUD'

    def get_exchange_rate(self, base='EUR'):
        url = 'http://data.fixer.io/api/latest'
        params = {
            'access_key': '93136301b1c8a659c34b8ce6bb63d0fa',
            'symbols': self.code,
            'base': base
        }
        response = requests.get(url, params)
        response.raise_for_status()
        return response.json()['rates'][self.code]

euro = Currency('Euro', 'European Central Bank', '€', 'EUR')
print(euro)

aus_dollar = Currency('Australian Dollar', 'Reserve Banks of Australia', '$')
print(aus_dollar)

rate = aus_dollar.get_exchange_rate(base=euro.code)
print(rate)
