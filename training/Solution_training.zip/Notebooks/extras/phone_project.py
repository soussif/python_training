"""Create some sample structured tabular text output

Phone numbers here are fictional as per: https://www.acma.gov.au/use-phone-numbers-fiction"""

import argparse

class PhoneInfo:
    def __init__(self, *, number:str, status:str, project:str="", description:str="") -> None:
        self.number = number
        self.status = status
        self.project = project
        self.description = description

    def __repr__(self) -> str:
        return f"PhoneInfo(number='{self.number}', status='{self.status}', project='{self.project}', description='{self.description}')"


class ProjectInfo:
    """Information about a specific project in the example Phone project"""
    def __init__(self, *, name:str, manager:str, description:str):
        self.name = name
        self.manager = manager
        self.description = description

    def __repr__(self) -> str:
        return f"ProjectInfo(name='{self.name}', manager='{self.manager}', description='{self.description}')"


phone_info = [
    PhoneInfo(number="0491 570 157",status="active",project="A", description="used to be in project B"),
    PhoneInfo(number="0491 570 158",status="active",project="A"),
    PhoneInfo(number="0491 570 159",status="disconnected",project="A"),
    PhoneInfo(number="0491 570 110",status="active",project="B", description="was disconnected on 2019/12/01 activated again 2019/12/02"),
    PhoneInfo(number="0491 570 313",status="active",project="B", description="previously was 0491 573 087"),
    PhoneInfo(number="0491 570 737",status="inactive",project="B", description="Deactivated 2019/06/09"),
    PhoneInfo(number="0491 571 266",status="disconnected",project="C"),
    PhoneInfo(number="0491 571 491",status="disconnected",project="C"),
    PhoneInfo(number="0491 571 804",status="active",project="C"),
    PhoneInfo(number="0491 572 549",status="active",project="C"),
    PhoneInfo(number="0491 572 665",status="active", project="Update"),
    PhoneInfo(number="0491 572 983",status="inactive", project="Update", description="Deactivated 2019/06/01"),
    PhoneInfo(number="0491 573 770",status="disconnected", project="Update"),
    PhoneInfo(number="0491 573 087",status="disconnected"),
]

projects_info = [
    ProjectInfo(name="A", manager="Ed", description="Project A"),
    ProjectInfo(name="B", manager="Errol", description="Project B"),
    ProjectInfo(name="C", manager="Henry", description="Project C"),
    ProjectInfo(name="Update", manager="Janis", description="Updating equipment using automation"),
]

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='This is an example script that prints out tabular text output for some phone number information.')
    parser.add_argument('--simple', help='Show simplified summary of output only. Display a table of phone numbers and status only, one record per line.', action='store_true')
    parser.add_argument('--projects', help='Show a summary of current projects.', action='store_true')

    args = parser.parse_args()

    if args.simple:
        print(f"{'number':12} {'status':12}")
        for phone in phone_info:
            number = phone.number
            status = phone.status
            print(f"{number:12} {status:12}")
    elif args.projects:
        for project in projects_info:
            print(f"Project: {project.name}")
            print("------------------------")
            print(f"Manager    : {project.manager}")
            print(f"Description: {project.description}")
            print()
    else:
        print(f"{'number':12} {'status':12} {'project':8} description")
        for phone in phone_info:
            number = phone.number
            status = phone.status
            project = phone.project
            description = phone.description
            print(f"{number:12} {status:12} {project:8} {description}")
