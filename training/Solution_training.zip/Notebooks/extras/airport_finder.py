from flask import Flask, render_template, request
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///airports.sqlite'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)


# coding: utf-8
from flask_sqlalchemy import SQLAlchemy

# Pasted in from the output of the sqlacodegen program above:
# Terminal / Command Prompt:
#     sqlacodegen sqlite:///airports.sqlite
class Airport(db.Model):
    __tablename__ = 'airports'

    id = db.Column(db.Integer, primary_key=True)
    Airport_ID = db.Column(db.BigInteger)
    Name = db.Column(db.Text)
    City = db.Column(db.Text)
    Country = db.Column(db.Text)
    IATA_FAA = db.Column(db.Text)
    ICAO = db.Column(db.Text)
    Latitude = db.Column(db.Float)
    Longitude = db.Column(db.Float)
    Altitude = db.Column(db.BigInteger)
    Timezone = db.Column(db.Float)
    DST = db.Column(db.Text)
    Tz_db_time_zone = db.Column(db.Text)

@app.route('/')
def select_country():
    #countries = ['United States', 'Australia', 'Egypt']
    countries = sorted({row.Country for row in Airport.query.distinct()})
    return render_template('select_country.html', countries=countries)

@app.route('/filter')
def filter_by_country():
    country = request.args.get('country', 'Nothing selected')
    airports_filtered = Airport.query.filter_by(Country=country)
    if airports_filtered.count() == 0:
        return 'No airports found'
    else:
        subset = [row.Name for row in airports_filtered]
        return render_template('show_airports.html', airports=subset, country=country)

###
# Contents of templates/select_country.html:
# <form action="/filter">
#   <label>Select country</label>
#   <select name="country">
#   {% for country in countries %}
#    <option value = "{{ country }}">{{ country }}</option>
#   {% endfor %}
#   </select>
#   <input type="submit" value="Find airports">
# </form>

###
# Contents of templates/show_airports.html:
# <h1>Airports in {{ country }}</h1>
# <ul>
#   {% for airport in airports %}
#     <li> {{ airport }} </li>
#   {% endfor %}
# </ul>
