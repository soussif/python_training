import logging
import requests


API_KEY = "ef29e1f100cb2a25ce2fb9f5816faa5d"
URL = "http://api.openweathermap.org/data/2.5/weather"


logging.basicConfig(
    filename='temperature.log',
    level=logging.INFO,
    format='%(asctime)s %(message)s'
)


def get_temperature(city, country_code='AU'):
    """
    Get the current temperature for a given placename
    
    Country is assumed to be Australia (ISO A2 country code
    AU), though this can easily be changed.
    
    If the request is for some reason unsuccessful it's raised
    as a requets.HTTPError
    
    Example:
    >>> get_temperature('Melbourne')
    17.6
    >>> get_temperature('Jakarta', 'ID')
    29.0
    """
    params = {
        'appid': API_KEY,
        'units': 'metric',
        'q': city
    }

    response = requests.get(URL, params)
    response.raise_for_status()
    
    return response.json()['main']['temp']


if __name__ == '__main__':
    city = 'Batemans Bay'
    temperature = get_temperature(city)
    logging.info(f'{city}: {temperature}')
