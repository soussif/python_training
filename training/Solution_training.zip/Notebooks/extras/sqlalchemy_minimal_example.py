from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.orm import sessionmaker, scoped_session
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

# an Engine, which the Session will use for connection
# resources
engine = create_engine('sqlite:///mytest.db')

# create a configured "Session" class
session_factory = sessionmaker(bind=engine)
Session = scoped_session(session_factory)

# create a Session
session = Session()


class User(Base):
    __tablename__ = 'users'

    id = Column(Integer, primary_key=True)
    name = Column(String)
    fullname = Column(String)
    nickname = Column(String)

    def __repr__(self):
        return "<User(name='%s', fullname='%s', nickname='%s')>" % (
            self.name, self.fullname, self.nickname)

Base.metadata.create_all(engine)

# work with sess
myobject = User(name='edward', fullname='Edward', nickname='Ed')
session.add(myobject)

myobject2 = User(name='janis', fullname='Janis', nickname='Jano')
session.add(myobject2)

session.commit()

print(list(session.query(User)))
