import random
import itertools
from solutions.blackjack_simulation_1 import Card

SUITS = ['diamonds', 'hearts', 'spades', 'clubs']
RANKS = ['ace'] + [str(value) for value in range(2, 11)] + ['jack', 'queen', 'king']

def is_bust(hand):
    '''
    Returns True if sum of values in Blackjack is over 21
    '''
    return sum([card.bj_value() for card in hand]) > 21


deck = [Card(rank, suit) for (rank, suit) in itertools.product(RANKS, SUITS)]
assert len(deck) == 52
# print(deck)

def main():
    myhands = [random.sample(deck, 3) for i in range(10**6)]
    print('First 3 hands are: ', myhands[:3])
    bust = [is_bust(hand) for hand in myhands]
    print('Estimated probability of a 3-card hand going bust is:', sum(bust) * 1.0 / len(bust))

if __name__ == '__main__':
    main()