folders = {}
for path in fs.ls('landsat-pds/c1/L8/090/085'):
    file_sizes = fs.du(path)
    folders[path] = sum(file_sizes.values())
    
print('Total size', sum(file_sizes.values()))
