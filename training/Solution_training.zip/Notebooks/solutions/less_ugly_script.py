import os
import sys
import string


def S(s):
    N = ''
    for I in range(len(s)):
        if s[I] not in string.ascii_uppercase:
            N = N + s[I]
    return N


print(S('I think, therefore I am a Weasel'))