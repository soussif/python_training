from collections import Counter

results = parse.findall('tweet:RT @{username:w}', text)
counts = Counter((result.named['username'] for result in results))

counts.most_common(5)
