olympics['Total'] = olympics['Gold'] + olympics['Silver'] + olympics['Bronze']
medals_per_person = olympics['Total'] / populations['2012']
medals_per_person.nlargest(10).plot(kind='bar')

print(len(olympics.join(populations, how='left')))
print(len(olympics.join(populations, how='right')))
print(len(olympics.join(populations, how='inner')))
print(len(olympics.join(populations, how='outer')))
