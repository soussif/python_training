from altair import datum
import numpy as np

agriculture_chart = alt.Chart(agriculture)

histogram_chart = agriculture_chart.mark_rect()
histogram_chart.encode(
    x='Region label',
    y=alt.Y('Gross value ($)', type='quantitative', bin=True),
    color=alt.Color('Gross value ($)', aggregate='count', )
)
