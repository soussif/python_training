cars.loc[~cars.index.duplicated(keep='first'), 'mpg'].unstack('origin')
