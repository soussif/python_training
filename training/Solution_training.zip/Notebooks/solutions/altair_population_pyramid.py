
abalone = pd.read_csv('Data/abalone.csv')

abalone_chart = alt.Chart(abalone).mark_bar().encode(
    x=alt.X('shucked weight', aggregate='mean'),
    y=alt.Y('rings', type='ordinal', sort=alt.SortOrder('descending')),
).properties(
    width=180,
    height=180,
).facet(
    column='sex'
)
abalone_chart
