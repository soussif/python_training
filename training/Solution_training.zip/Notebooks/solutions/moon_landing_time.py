tz = get_localzone()

moon = pd.Series({
    'landing': pd.Timestamp('1969-07-20 20:18'),
    'Armstrong': pd.Timestamp('1969-07-21 02:56:15'),
    'Aldrin': pd.Timestamp('1969-07-21 02:56:15') + pd.Timedelta('20 minutes'),
}).dt.tz_localize('utc')

moon.dt.tz_convert(tz)
