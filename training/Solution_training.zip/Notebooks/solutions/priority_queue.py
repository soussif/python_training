import queue
import random
import threading
import time

from faker import Faker


coffeeshop_queue = queue.PriorityQueue()
fake_factory = Faker()
for _ in range(7):
    name = fake_factory.name()
    print(f'{name} joined the line')
    coffeeshop_queue.put((2, name))
for _ in range(3):
    name = fake_factory.name()
    print(f'{name} ordered online')
    coffeeshop_queue.put((1, name))

def announcement(s):
    print('{}: {}'.format(threading.current_thread().name, s))

def make_coffee(q):
    announcement('starting shift')
    while not q.empty():
        priority, name = q.get()
        time.sleep(random.random())  # it might take a little time to process the ticket.
        announcement(f'{name} coffee up!')
        q.task_done()
    announcement('ending shift')

num_staff = 2

for i in range(num_staff):
    worker = threading.Thread(
        target=make_coffee,
        args=(coffeeshop_queue,),
        name=f'barrista {i}',
    )
    worker.start()
    
coffeeshop_queue.join()
