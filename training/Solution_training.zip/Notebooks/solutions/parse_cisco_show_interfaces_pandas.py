""" Example of how to parse the output from a cisco `show interfaces description` command
using the TextFSM library"""
import pandas
import textfsm

# Load in the data from the router command
with open("interfaces_output.txt", encoding='UTF-8', mode='rt') as device_input:
    raw_text_data = device_input.read()

# Load in the TextFSM template
with open("cisco_show_interfaces.textfsm", mode='rt') as template:
    re_table = textfsm.TextFSM(template)
fsm_results = re_table.ParseText(raw_text_data)

description_results = pandas.DataFrame(columns=['PORT', 'STATUS', 'PROTOCOL', 'DESCRIP'])

# Extract each row from the parsed input
for row in fsm_results:
    description_results = description_results.append({
        'PORT': row[0],
        'STATUS': row[1],
        'PROTOCOL': row[2],
        'DESCRIP': row[3],
    }, ignore_index=True)

admin_down_filter = description_results['STATUS'] == "admin down"
admin_down = description_results[admin_down_filter]

print(f'There were {len(admin_down)} interfaces in the "admin down" state')


upgrade_project_filter = description_results['DESCRIP'].str.contains("upgrade project")
upgrade_project_interfaces = description_results[upgrade_project_filter]

print(f'The following interfaces are involved in the upgrade project')
print(upgrade_project_interfaces.to_string())