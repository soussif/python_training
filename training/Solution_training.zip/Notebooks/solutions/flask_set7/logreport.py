from flask import Flask, abort
from flask import session
from flask import flash

from flask import jsonify

app = Flask(__name__)

from flasgger import Swagger
Swagger(app)

@app.route("/hello")
def hello():
    """
    Says hello to a logged in user
    ---
    tags:
      - helloapi
    parameters:
      - name: number
        in: query
        type: int
        description: number of times to do the greeting
    responses:
      200:
        description: A dictionary with a greeting
        schema:
          logged_in: true if the user is logged in
          message: the greeting to the user
          number: the number of times the greeting was given
          username: the username of the currently logged in user
    """
    number = int(request.args.get("number", 1))
    if 'username' in session:
        # User is logged in, perform some action for members
        data = {}
        data['logged_in'] = True
        data['username'] = session['username']
        data['message'] = "Hello {}!".format(session['username']) * number
        return jsonify(**data)
    else:
        # No user is logged in, probably redirect to the login page
        return redirect("/login")

@app.route("/hello/<username>")
def hello_world(username):
    return 'Hello {}!'.format(username)

@app.route("/convert/<GiB>")
def convert(GiB):
    """
    Converts GiB to bytes
    ---
    summary: Conversion from GiB to bytes
    operationId: convertGiB
    tags:
    - GiB
    parameters:
    - name: GiB
      in: path
      required: true
      description: The GiB value to convert
      type: float
    responses:
    200:
      description: Expected response to a valid request
      schema:
        $ref: GiB
    """
    if not is_number(GiB):
        abort(400)
    return "{} GiB is {} bytes".format(GiB, float(GiB) * 1024**3)

def is_number(s):
    try:
        # Try convert to a number -- if this fails, a ValueError occurs
        float(s)
        # Above code succeeded -- s must be a number, or able to be interpreted as one
        return True  
    except ValueError:
        # float conversion failed, so not a number
        return False

@app.route("/")
def index():
    return "Hello world!"

from flask import render_template, request

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        if request.form['username'] == "user" and request.form['password'] == "swordfish":
            # Valid username and password
            session['username'] = request.form['username']
            return render_template('hello.html', username=session['username'])
        else:
            # Invalid username/password combination
            flash("Incorrect login, try again")
            return redirect("/login")
    else:
        # Show the user the login form
        return render_template('login.html')

from flask import redirect

@app.route("/logout")
def logout():
    session.pop("username")
    return redirect("/")

if __name__ == '__main__':
    app.secret_key = 'A0Zr98j/3yX R~XHH!jmN]LWX/,?RT'
    app.run(debug=True)
