census = pd.read_csv('LargeData/roles_by_place_of_work.csv', skiprows=6, index_col=0, skipfooter=5)
census.drop(columns='Total', inplace=True)

census.loc[census.index.str.contains('manag(?:er|ing)', flags=re.I)].sum().nlargest(10).plot(kind='bar')
