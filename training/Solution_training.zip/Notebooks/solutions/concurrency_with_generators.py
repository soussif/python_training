"""

"""

def countdown_gen(n):
    while n > 0:
        print('Down', n)
        yield
        n -= 1

def countup_gen(n):
    x = 0
    while x < n:
        print('Up', x)
        yield
        x += 1
        
import time

g1 = countdown_gen(5)
g2 = countup_gen(5)

for i in range(5):
    next(g1)
    next(g2)
    time.sleep(0.99)
