from dateutil import parser
import requests
import traitlets


class Commodity(traitlets.HasTraits):
    """
    Represents a commodity class stored on a remote server
    where you do not have direct access to the database.
    """

    name = traitlets.Unicode()
    price = traitlets.Float()
    id = traitlets.Integer()

    _last_modified = None
    _session = requests.Session()
    _session.auth = ('trainee@pythoncharmers.com', 'P@ssw0rd')
    _base_url = 'https://7f06wsuke3.execute-api.ap-southeast-2.amazonaws.com/dev'

    @property
    def last_modified(self):
        """
        Protect the last modified date so it can't be overwritten.
        """
        return parser.parse(self._last_modified)

    @traitlets.validate('id')
    def _validate_id(self, proposal):
        """
        This method should call the URL with the session.

        Having done so it should populate the name, and the
        _last_modified value, before returning proposal['value']
        """
        url = f"{self._base_url}/{proposal['value']}"
        response = self._session.get(url)
        response.raise_for_status()
        data = response.json()
        self.name = data['name']
        self._last_modified = data['last_modified']
        return proposal['value']

    @traitlets.default('id')
    def _default_id(self):
        """
        This method assumes that both name and price have
        been populated. Post to the URL with the `session`
        and return the response ['id']
        """
        url = f"{self._base_url}/"
        data = {
            'name': self.name,
            'price': self.price
        }
        response = self._session.post(url, data=data)
        response.raise_for_status()
        return response.json()['id']

    @traitlets.observe('price')
    def _watch_price(self, change):
        """
        This method updates the server with the
        price change. This method should `put` on the session
        and update the `_last_modified` attribute.
        """
        url = f"{self._base_url}/{self.id}"
        data = {
            'price': change['new']
        }
        response = self._session.put(url, data=data)
        response.raise_for_status()
        out_data = response.json()
        self._last_modified = out_data['last_modified']

    def __repr__(self):
        """
        Nice representation of the commodity
        """
        return f'Commodity ({self.id} {self.name} {self.price} {self.last_modified})'
