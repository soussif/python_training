import pandas as pd

olympics = pd.read_csv('Data/olympics2012.csv', index_col='Country')
olympics['Total'] = olympics['Gold'] + olympics['Silver'] + olympics['Bronze']
print(olympics.sort_values('Total', ascending=False).head(1))
print('Australia', olympics['Total'].rank(ascending=False)['Australia'])
olympics['Weighted Total'] = olympics['Gold'] * 7 + olympics['Silver'] * 3 + olympics['Bronze']
print(olympics.sort_values('Weighted Total', ascending=False).head(1))
