
forbes = pd.read_csv('Data/forbes1964.csv')
aus_companies = forbes.loc[forbes['country'] == 'Australia']
print(aus_companies.head(1))
print(aus_companies['profits'])

top_20_australian = aus_companies[:20]
top_20_australian.set_index('name')['profits'].plot(kind='bar')
