"""
subnet_addresses.py: solution to this exercise:

Write a function that will take an IP address and a subnet mask length and
return a list of the addresses on that subnet.
"""

def get_subnet_addresses(address, mask_length):
    """Get all IP addresses on the subnet that is defined by `address` with the given subnet mask length"""
    if not isinstance(address, ipaddress.IPv4Address):
        raise TypeError(f"address must be of type ipaddress.IPv4Address, got {type(address)}")
    iface_str = f"{str(address)}/{mask_length}"
    iface = ipaddress.IPv4Interface(iface_str)
    net = iface.network
    addresses = list(net.hosts())
    return addresses

