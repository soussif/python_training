sex = {'F': 'Female', 'I': 'Indeterminate', 'M': 'Male'}
abalone['sex'].apply(sex.get)
# or
abalone['sex'].map(sex)
