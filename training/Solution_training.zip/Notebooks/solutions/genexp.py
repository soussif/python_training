from calendar import isleap

leap_years = (year for year in range(2000, 2030) if isleap(year))

# We see the values:
for year in leap_years:
    print(year)

# This now prints an empty list:
print(list(leap_years))

# No further iteration is possible; the generator is exhausted.
