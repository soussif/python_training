import gzip

with open('Data/olympics2012.csv') as f, gzip.open(fs.open('pythoncharmers-psma-training/olympics2012.csv.gz', 'wb'), 'wt') as out:
    out.write(f.read())
