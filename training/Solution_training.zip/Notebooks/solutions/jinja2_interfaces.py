from jinja2 import Environment, PackageLoader

env = Environment(loader=PackageLoader(__name__, 'templates'))
template = env.get_template('interfaces.cfg')

interfaces = [{'slotid': i, 'portid': 8000 + i, 'description': 'eth0', 'channelGroup': 'A'}
              for i in range(4)]

print(template.render(interfaces=interfaces))
