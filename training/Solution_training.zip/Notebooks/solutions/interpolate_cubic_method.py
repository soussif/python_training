stocks = pd.read_csv(
    'Data/sampled_tesla.csv', 
    parse_dates=['timestamp'], 
    index_col='timestamp'
)[['low', 'low with missing']]
stocks.index = stocks.index.tz_localize(tz=None)

rmse = ((stocks['low'] - stocks['low with missing'].interpolate(method='cubic', order=5))**2).mean()**0.5
rmse
