### Exercise:
# Write a function `read_csv_from_zip(zip_filename, name)` which reads and returns
# the given file `name` from inside the zip file as a DataFrame.

def read_csv_from_zip(zip_filename, name, *args, **kwargs):
    zf = zipfile.ZipFile(zip_filename)
    buffer = BytesIO(zf.read(name))
    df = pd.read_csv(buffer, *args, **kwargs)
    return df

