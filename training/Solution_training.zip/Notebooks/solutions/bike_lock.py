from itertools import chain, product
for c in product(chain(range(10), 'abcdef'), repeat=4):
    print(*c)
