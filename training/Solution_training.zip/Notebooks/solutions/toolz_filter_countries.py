countries = set(['Australia', 'Netherlands', 'United Kingdom'])
tz.keyfilter(
    lambda c: c in countries, 
    tz.groupby(lambda n: forbes.loc[n, 'country'], forbes['name'])
)