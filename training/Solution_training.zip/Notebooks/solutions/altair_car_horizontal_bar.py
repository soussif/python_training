import pandas as pd
import altair as alt

cars = pd.read_csv('Data/Auto.csv', index_col=0)
chart = alt.Chart(cars)

bar_chart = chart.mark_bar()
bar_chart.encode(
    alt.X('cylinders', aggregate='count', title='Number of cars'),
    alt.Y('cylinders', type='ordinal', sort='descending', title='Cylinders'),
    alt.Color('origin', type='nominal', title='Origin'),
    alt.Row('origin', title='Manufacture origin')
)
