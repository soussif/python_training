abalone = pd.read_csv('Data/abalone.csv')

abalone_chart = alt.Chart(abalone).encode(
    y=alt.Y(
        'rings',
        type='ordinal',
        sort=alt.SortOrder('descending'),
        scale=alt.Scale(domain=list(range(29, 0, -1)), clamp=True),
        axis=None
    )
)

female = abalone_chart.mark_bar(color='green').encode(
    x=alt.X('shucked weight', aggregate='mean', sort=alt.SortOrder('descending'))
).transform_filter(
    alt.datum['sex'] == 'F'
)

middle = abalone_chart.mark_text(color='black').encode(
    text=alt.Text('rings:O', aggregate='mean'),
).properties(width=20)

male_indeterminate = abalone_chart.mark_bar(opacity=0.7).encode(
    x=alt.X('shucked weight', aggregate='mean', stack=False),
    color=alt.Color('sex', type='nominal', scale=alt.Scale(domain=['M', 'I'], range=['green', 'gold']), legend=None)
).transform_filter(
    alt.datum['sex'] != 'F'
)

alt.concat(female, middle, male_indeterminate)
