import random
from solutions.blackjack_simulation_1 import Card
from solutions.blackjack_simulation_2 import deck, is_bust

myhands = (random.sample(deck, 3) for i in range(10**6))

bust = (is_bust(hand) for hand in myhands)

def proportion(bool_values):
    '''
    An average function that works for generators (which have no len()).
    In Python 3.4+, you can simply use mean() in the statistics module
    instead.
    '''
    mysum = 0.0
    for n, value in enumerate(bool_values):
        mysum += value
    return mysum / n

print("Estimating proportion of 3-card hands that went 'bust' (over 21):", end=None)
print(proportion(bust))
