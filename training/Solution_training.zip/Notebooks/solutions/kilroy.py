from fabric import Connection

conn = Connection(
    'ec2-13-211-219-60.ap-southeast-2.compute.amazonaws.com', 
    user='trainee', 
    connect_kwargs={'password': 'python'}
)
conn.put('Data/kilroy_was_here.png', 'henry.png')
result = conn.run('ls', hide=True)
print(result.stdout.strip().split('\n'))