"""
Much nicer script.

All thanks to pylint.
"""
import string


def remove_uppercase(candidate):
    """
    All functions should have docstrings.

    In this case, remove capital letters from some candidate
    string. Return a new string with the letters removed.
    """
    shortened = ''
    for letter in candidate:
        if letter not in string.ascii_uppercase:
            shortened += letter
    return shortened


print(remove_uppercase('I think, therefore I am a Weasel'))