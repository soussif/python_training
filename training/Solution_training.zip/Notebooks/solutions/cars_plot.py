cars = pd.read_csv('Data/Auto.csv')
cars['origin'] = cars['origin'].map({1: 'US', 2: 'EU', 3: 'JP'})
chart = alt.Chart(cars)
circle_chart = chart.mark_circle()
circle_chart.encode(
    x='mpg',
    y='acceleration',
    color='origin',
)
