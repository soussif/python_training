import json

from flask import Flask, render_template_string, abort

template = """
<h1>{{ name }}</h1>
{% if rating is not none %}
<h2>Rating: {{ rating }} of 5</h2>
{% else %}
<p>No reviews recorded</p>
{% endif %}
{% for review in reviews %}
<p>{{ review.text}} <em>{{ review.author }}</em></p>
{% endfor %}
"""
coffeeshop_data = json.load(open('coffeeshop.json'))

app = Flask(__name__)


@app.route("/<coffeeshop_id>")
def coffeeshop(coffeeshop_id):
    try:
        coffeeshop = coffeeshop_data['coffeeshop'][coffeeshop_id]
    except KeyError:
        abort(404)

    reviews = coffeeshop_data['reviews'][coffeeshop_id]

    if reviews:
        rating = sum([r['rating'] for r in reviews]) / len(reviews)
    else:
        rating = None

    return render_template_string(
        template,
        name=coffeeshop['name'],
        rating=rating,
        reviews=reviews
    )


@app.after_request
def gnu_terry_pratchett(resp):
    resp.headers.add("X-Clacks-Overhead", "GNU Terry Pratchett")
    return resp


if __name__ == '__main__':
    app.run()
