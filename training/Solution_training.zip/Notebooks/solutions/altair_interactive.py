rectangle = alt.selection_interval()

mpg_weight_chart = chart.mark_point().encode(
    alt.X('mpg'),
    alt.Y('weight'),
    color=alt.condition(
        rectangle,   # selection True
        alt.value('blue'),  # if inside selection
        alt.value('lightgray')  # if not in the selection
    )
).add_selection(
    rectangle
)

horesepower_acceleration_chart = chart.mark_point().encode(
    alt.X('horsepower'),
    alt.Y('acceleration'),
    color=alt.condition(
        rectangle,   # selection True
        alt.value('green'),  # if inside selection
        alt.value('lightgray')  # if not in the selection
    )
).add_selection(
    rectangle
)

alt.concat(mpg_weight_chart, horesepower_acceleration_chart)
