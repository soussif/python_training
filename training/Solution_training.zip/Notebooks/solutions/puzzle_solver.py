from itertools import permutations
import bz2
from flask import Flask, render_template
app = Flask(__name__)

@app.route("/")
def index():
    return render_template('index.html')

def read_words():
    """
    Read the Websters dictionary and return a set of its unique uppercase words.
    """
    file = bz2.open('Data/websters_dictionary.txt.bz2')
    data = file.read()
    websters = data.decode('latin-1')
    wordset = set(websters.upper().split())
    return wordset

WORDSET = read_words()

def solve(puzzle):
    """
    Given a jumbled sequence of letters, find any permutations
    which appear in the Websters dictionary.
    
    Return a set of solutions.
    
    Ignores case.
    """
    candidates = {''.join(perm) for perm in permutations(puzzle)}
    return candidates & WORDSET

from flask import request

@app.route("/solve", methods=['GET', 'POST'])
def answer():
    puzzle = request.form['puzzle'].upper()
    solutions = solve(puzzle)
    return "The answer is " + solutions + "!"
