import pandas as pd

data = [
    {'floral': 'Golden Wattle', 'bird': 'Emu', 'mammal': 'Red kangaroo'},
    {'floral': 'Royal Bluebell', 'bird': 'Gang-gang cockatoo'},
    {'floral': 'New South Wales Warratah', 'bird': 'Laughing kookaburra', 'mammal': 'Platypus'},
    {'floral': "Sturt's Desert Rose", 'bird': 'Wedge-tailed eagle', 'mammal': 'Red kangaroo'},
    {'floral': 'Cooktown Orchid', 'bird': 'Brolga', 'mammal': 'Koala'},
    {'floral': "Sturt's Desert Pea", 'bird': 'Piping shrike', 'mammal': 'Southern hairy-nosed wombat'},
    {'floral': 'Tasmanian Blue Gum', 'bird': 'Yellow wattlebird', 'mammal': 'Tasmanian devil'},
    {'floral': 'Pink Heath', 'bird': 'Helmeted honeyeater', 'mammal': "Leadbeater's possum"},
    {'floral': 'Red and Green Kangaroo Paw', 'bird': 'Black swan', 'mammal': 'Numbat'},
]
index = ['Australia', 'ACT', 'NSW', 'NT', 'Qld', 'SA', 'Tas', 'Vic', 'WA']
emblems = pd.DataFrame(data, index=index)
emblems
