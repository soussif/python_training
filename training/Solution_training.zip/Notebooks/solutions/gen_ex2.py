allfiles = (files for (path, folders, files) in os.walk('/'))
pyfiles = (f for f in chain.from_iterable(allfiles)
           if f.endswith('.py'))

# Example use:
print(next(pyfiles))

# Example: next 10
print(list(islice(pyfiles, 10)))