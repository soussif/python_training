url_pattern = r"""
    (?:ht|s?f|sm)tps?://   # match the protocols http, https, ftp, sftp, smtp
    (?P<host>              # match the host which should be in the form a.bc
       (?:[\d\w\-]+\.)+
       [\d\w\-]+
    )
    (?P<path>              # match the path on the server in the form /d/e/f.g    
        (?:/(?:[\d\w\-]|(?:%[0-9a-fA-F][0-9a-fA-F]))*)+
        (?:\.[\d\w-]+)?
    )?
    (?P<params>            # match get parameters that aren't whitespace
        \?(?:[\d\w\-\=\&]|(?:%[0-9a-fA-F][0-9a-fA-F]))*
    )?
"""

found_urls = set((
    m.group(0)
    for m in 
    re.finditer(url_pattern, text, flags=re.I | re.M | re.X)
))

their_url_pattern = r"""https?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+"""

set(re.findall(their_url_pattern, text, flags=re.I | re.M)) - found_urls
