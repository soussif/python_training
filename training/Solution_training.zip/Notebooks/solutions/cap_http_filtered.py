import pyshark

my_interface = 'enp5s0'
filtered_cap = pyshark.LiveCapture(my_interface, bpf_filter='tcp port 80')
filtered_cap.sniff(packet_count=10)
for pkt in filtered_cap:
    print(pkt.highest_layer)
