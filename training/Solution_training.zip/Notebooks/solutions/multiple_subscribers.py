def barista(name, **kwargs):
    print(f'Making coffee for {name}')
    
coffee_orders.connect(barista)

def cashier(name, size, **kwargs):
    if size == 'Small':
        return '$3.50'
    elif size == 'Large':
        return '$4.50'
    
coffee_orders.connect(cashier)

coffee_orders.send('Henry', size='Large')
coffee_orders.send('Hannah', size='Small')
coffee_orders.send('Marcie', size='Large')
