def leapyears(min_year, max_year):
    for year in range(min_year, max_year):
        if is_leap_year(year):
            yield year
            
# Example:
leap = leapyears(1950, 2020)
next(leap)