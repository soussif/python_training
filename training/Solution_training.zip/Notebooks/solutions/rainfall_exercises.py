import pandas as pd
rain = pd.read_csv(filename, header=None, names=['Date', 'Rainfall'],
                   parse_dates=['Date'], dayfirst=True,
                   index_col='Date')

# Exercise 1
def last_time_it_rained_this_much(rain: pd.DataFrame, amount: float) -> dt.datetime:
    "Compute the previous date it rained at least this much"
    return rain.loc[(rain["Rainfall"] > amount)].index.max()  # or .index[-1] if you know it's sorted by index

last_time_it_rained_this_much(rain, 2500)


# Exercise 2
rolling_week_rainfall = rain.rolling(7)['Rainfall'].apply(sum)
print("The 7 driest days ended on {} with a total rainfall of just {} points!".format(rolling_week_rainfall.idxmin(),
                                                                                     rolling_week_rainfall.min()))


# Harder Exercise 3
monthly_average = rain.groupby(rain.index.month).mean()['Rainfall']
rain["MoreThanMonthlyAverage"] = rain['Rainfall'] > monthly_average.loc[rain.index.month].values
print("Days with more rain than the overall monthly average:")
print(rain[rain["MoreThanMonthlyAverage"]].head())  # Remove head() to see them all

# Harder Exercise 4
print("Days with more rain than the average for its current month:")
current_monthly_average = rain.groupby([rain.index.year, rain.index.month]).mean()['Rainfall']
rain["MoreThanCurrentMonth"] = rain['Rainfall'] > current_monthly_average.loc[zip(rain.index.year, rain.index.month)].values
print(rain.head())
