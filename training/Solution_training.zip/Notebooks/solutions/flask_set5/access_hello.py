from requests import Session

# Create a session to allow for logins
s = Session()

data = {"username": "user", "password": "swordfish"}
response = s.post("http://127.0.0.1:5000/login", data=data)


# For Question 1 use:
response = s.get("http://127.0.0.1:5000/hello")
print(response.text)

# For Question 3 use:
response = s.get("http://127.0.0.1:5000/hello")
print(response.json())
# or:
from pprint import pprint
response = s.get("http://127.0.0.1:5000/hello")
pprint(response.json())

