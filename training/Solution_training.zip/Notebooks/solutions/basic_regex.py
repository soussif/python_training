from collections import Counter
counts = Counter(re.findall(r'@\w+', text))

counts['@pyconau']
