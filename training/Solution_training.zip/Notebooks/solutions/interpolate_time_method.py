stocks = pd.read_csv(
    'Data/sampled_tesla.csv', 
    parse_dates=['timestamp'], 
    index_col='timestamp'
)[['high', 'high with missing']]

rmse = ((stocks['high'] - stocks['high with missing'].interpolate(method='time'))**2).mean()**0.5
rmse
