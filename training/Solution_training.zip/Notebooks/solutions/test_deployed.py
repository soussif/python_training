from urllib.parse import urljoin

import environs
import pytest
import requests


env = environs.Env()
env.read_env(path='testing.env', recurse=False)
server_urls = env.list('SERVER_URLS')
document_path = env('DOCUMENT_PATH')


@pytest.mark.parametrize('url', server_urls)
def test_default_image_generation(url):
    r = requests.get(url)
    r.raise_for_status()


@pytest.mark.parametrize('url', server_urls)
def test_default_word_count(url):
    wordcount_url = urljoin(url, 'wordcount')
    r = requests.get(wordcount_url)
    r.raise_for_status()


@pytest.mark.parametrize('url', server_urls)
def test_post_image_generation(url):
    r = requests.post(
        url,
        data={'document': open(document_path)}
    )
    r.raise_for_status()


@pytest.mark.parametrize('url', server_urls)
def test_post_word_count(url):
    wordcount_url = urljoin(url, 'wordcount')
    r = requests.post(
        wordcount_url,
        data={'document': open(document_path)}
    )
    r.raise_for_status()
