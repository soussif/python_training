cleaned_text = unicodedata.normalize('NFKD', text).casefold()

print(len(cleaned_text), len(text))

cleaned_text.count('#pyconau')
