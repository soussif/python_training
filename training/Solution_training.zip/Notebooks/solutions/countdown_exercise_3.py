import datetime as dt
import asyncio
import time

async def countdown(n=5):
    for i in range(n, 0, -1):
        print('Time', dt.datetime.now(), 'Down', i)
        await asyncio.sleep(1)

async def main():
    print('Start', dt.datetime.now())
    task1 = asyncio.create_task(countdown(n=5))

    # This no longer blocks:
    await asyncio.sleep(2)

    await task1
    
    print('End', dt.datetime.now())

asyncio.run(main())
