agriculture_chart = alt.Chart(agriculture)

histogram_chart = agriculture_chart.mark_rect()
histogram_chart.encode(
    x='Region label',
    y=alt.Y('Commodity description', axis=alt.Axis(labelLimit=500)),
    color='Gross value ($)',
)
