zen = open('Data/zen.utf16.txt', encoding='utf-16').read()
print(len(zen.encode()), len(zen.encode('utf-16')))
print(zen.encode().decode('utf-16'))
