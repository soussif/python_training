"""
Exercise solution - timeme decorator
"""

def timeme(func):
    def inner(*args, **kwargs):
        start = time.time()
        
        result = func(*args, **kwargs)
        
        end = time.time()
        elapsed = end - start
        print(f'Function took {elapsed:.3f} seconds')
        return result
    return inner


# Refinement: use `functools.wraps` to preserve the name and docstring of
# the original function:

from functools import wraps

def timeme(func):
    @wraps(func)
    def inner(*args, **kwargs):
        start = time.time()
        
        result = func(*args, **kwargs)
        
        end = time.time()
        elapsed = end - start
        print(f'Function took {elapsed:.3f} seconds')
        return result
    return inner




