stock_symbols = multiprocessing.JoinableQueue()


for row in random.sample(open('extras/stock_symbols.jl').readlines(), 20):
    stock_symbols.put(json.loads(row)) 

closing_prices = multiprocessing.SimpleQueue()

def stock_worker(q_in, q_out):
    """
    Simple worker, reads from the q_in and writes to q_out.
    
    Keeps going until the input queue is empty.
    """
    while True:
        try:
            symboldata = q_in.get(timeout=2)
            symboldata['closing_price'] = get_closing_price(symbol=symboldata['symbol'])
            q_out.put(symboldata)
            q_in.task_done()
        except multiprocessing.queues.Empty:
            break

jobs = []
for _ in range(5):  # start up 5 processes (which is overkill) to do the work
    p = multiprocessing.Process(target=stock_worker, args=(stock_symbols, closing_prices))
    jobs.append(p)
    p.start()

[j.exitcode for j in jobs]

stock_symbols.join()

while not closing_prices.empty():
    print(closing_prices.get())