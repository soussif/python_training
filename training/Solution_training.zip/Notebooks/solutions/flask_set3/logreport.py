from flask import Flask, abort, render_template, request

app = Flask(__name__)

@app.route("/hello")
def hello():
    return render_template('hello.html')

@app.route("/hello/<username>")
def hello_world(username):
    return 'Hello {}!'.format(username)

@app.route("/convert/<GiB>")
def convert(GiB):
    if not is_number(GiB):
        abort(400)
    return "{} GiB is {} bytes".format(GiB, float(GiB) * 1024**3)

def is_number(s):
    try:
        # Try convert to a number -- if this fails, a ValueError occurs
        float(s)
        # Above code succeeded -- s must be a number, or able to be interpreted as one
        return True  
    except ValueError:
        # float conversion failed, so not a number
        return False

@app.route("/")
def index():
    return "Hello world!"

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        if request.form['username'] == "user" and request.form['password'] == "swordfish":
            # Valid username and password
            return render_template('hello.html')
        else:
            # Invalid username/password combination
            return "bad"
    else:
        # Show the user the login form
        return render_template('login.html')

if __name__ == '__main__':
    app.run(debug=True)
