long_gdp = gdp.loc[countries].reset_index().melt(
    id_vars=['Country Name'],
    var_name='Year',
    value_name='GDP'
)
long_gdp['Year'] = long_gdp['Year'].astype('int')

import statsmodels.api as sm

model = sm.formula.ols(
    'GDP ~ C(Q("Country Name")) + Year - 1',
    long_gdp
).fit()

model.predict(
    pd.DataFrame([
        {'Country Name': 'Australia', 'Year': 2019},
        {'Country Name': 'New Zealand', 'Year': 2019},
        {'Country Name': 'Greece', 'Year': 2019},
        {'Country Name': 'Netherlands', 'Year': 2019}
    ],
        index=countries
    )
)
