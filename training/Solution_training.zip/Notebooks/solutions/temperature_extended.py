import requests
import time


weather_url = "http://api.openweathermap.org/data/2.5/weather"


def get_temperature(placename, country_code=None):

    if country_code:
        location = f'{placename},{country_code}'
    else:
        location = placename
    
    params = {
        'appid': "ef29e1f100cb2a25ce2fb9f5816faa5d",
        'q': location,
        'units': 'metric'
    }
    time.sleep(0.5)
    
    response = requests.get(weather_url, params)
    response.raise_for_status()
    weather = response.json()
    return weather['main']['temp']


import csv
import random

for row in random.sample(list(csv.DictReader(open('Data/countries.csv', encoding='latin-1'))), 10):
    print(row['capital'], '(', row['name'], ')', end=' ')
    try:
        temp = get_temperature(row['capital'], row['2 letter ISO abbreviation'])
        print(f'{temp:.2f}°C')
    except:
        print('Not found')
