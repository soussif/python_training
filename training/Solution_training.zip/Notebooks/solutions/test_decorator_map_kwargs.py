"""
Unit tests for the map_kwargs function
"""
import pytest

from decorator_map_kwargs import map_kwargs

@map_kwargs({'hue': 'color', 'colour': 'color'})
def violinplot(color=None):
    """
    Do some plotting ...
    ... but for now, just return the color kwarg.

    [This docstring should be preserved despite the decorator...]
    """
    return {'color': color}

def test_map_kwargs_exclusive():
    with pytest.raises(ValueError):
        violinplot(hue='Cylinders', color='Cylinders')

def test_map_kwargs_preserves_decorator():
    assert 'preserved' in violinplot.__doc__

def test_normalize():    
    # These should normalize "hue" and "colour" to "color":
    assert violinplot(hue='Cylinders') == {'color': 'Cylinders'}
    assert violinplot(colour='Cylinders') == {'color': 'Cylinders'}

def test_boring():
    # The obvious thing should also work:
    assert violinplot(color='Cylinders') == {'color': 'Cylinders'}