cars.sort_values('weight', inplace=True)

weight_rank = cars['weight'].rank(method='min')

weight_rank.iloc[cars['weight'].searchsorted(2849) + 1]
