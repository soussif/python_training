import matplotlib.pyplot as plt
import seaborn

def score_against_olympics(name):
    """Use Jaro-Winkler to score against olympics and return a Series of results"""
    return pd.Series(
        v_jaro_winkler(olympics_missing, name),
        index=olympics_missing
    )

match_scores = population_missing.to_series().apply(score_against_olympics)

plt.figure(figsize=(10, 10))
seaborn.heatmap(match_scores, cmap='Greens')

country_name_map = match_scores[match_scores > 0.9].idxmax().dropna().to_dict()

olympics.rename(index=country_name_map, inplace=True)

olympics['Total'] = olympics[['Gold', 'Silver', 'Bronze']].sum(axis='columns')

medals_per_person = olympics['Total'] / population['2012']

medals_per_person.nlargest(10).plot(kind='bar')

len(medals_per_person) - medals_per_person.isnull().sum()
