import requests


url = 'https://www.alphavantage.co/query'
params = {
    'function': 'TIME_SERIES_INTRADAY',
    'interval': '1min',
    'apikey': 'XTB3CTET1WMOJPCH'
}


def get_closing_price(symbol):
    params['symbol'] = symbol
    data = requests.get(url, params).json()['Time Series (1min)']
    return float(data[max(data.keys())]['4. close'])


for stock in ['INGA', 'ABN', 'SLB']:
    print(get_closing_price(stock))