import numpy as np
import pandas as pd
import scipy.stats

big_mac_index = pd.read_excel('Data/BigMacIndex2000toJan2018.xls', 'Jan2018')
dollar_values = big_mac_index[['dollar_valuation', 'dollar_adj_valuation']].dropna().values

zscore = (dollar_values - np.mean(dollar_values, axis=0)) / np.std(dollar_values, axis=0)

print(np.allclose(zscore, scipy.stats.zscore(dollar_values, axis=0)))