
import datetime as dt
import asyncio
import time

async def countdown(n=5):
    for i in range(n, 0, -1):
        print('Time', dt.datetime.now(), 'Down', i)
        await asyncio.sleep(1)

async def countup(n=5):
    for i in range(n):
        print('Time', dt.datetime.now(), 'Up', i)
        await asyncio.sleep(1)
        
async def main():
    print('Start', dt.datetime.now())
    task1 = asyncio.create_task(countdown(n=5))
    task2 = asyncio.create_task(countup(n=5))

    await asyncio.sleep(2)
    await task1, task2

    print('End', dt.datetime.now())

asyncio.run(main())
