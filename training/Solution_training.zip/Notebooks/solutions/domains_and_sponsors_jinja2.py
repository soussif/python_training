from jinja2 import Environment, FileSystemLoader

env = Environment(loader=FileSystemLoader('templates'))
template = env.get_template('domains.yml')

import pandas as pd
domains = pd.read_csv('~/Data/net/rootzonedb.txt', sep='\t', index_col=0)
data = domains['Sponsoring Organisation']

output = template.render(data=data)

with open('new_domains.yml', mode='wt', encoding='utf8') as f:
    f.write(output)
