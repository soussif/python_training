import ipaddress
from typing import List

import dns.resolver


def IPv6_DNS(domain_name: str) -> List[ipaddress.IPv6Address]:
    """Look up the IPv6 records for the given domain name `name`"""
    results = []
    try:
        answers = dns.resolver.query(domain_name, 'AAAA')
    except dns.resolver.NoAnswer:
        print("There was no AAAA record found for", domain_name)
    else:
        for result in answers:
            address = ipaddress.ip_address(result.address)
            results.append(address)
    return results