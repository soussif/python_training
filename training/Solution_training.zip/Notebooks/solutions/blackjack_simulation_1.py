class Card:
    """
    A playing card. Example uses:
    >>> c1 = Card('10', 'hearts')
    >>> c2 = Card('queen', 'spades')
    """
    def __init__(self, rank, suit):
        (self.rank, self.suit) = (rank, suit)

    def is_royal(self):
        return self.rank in {'jack', 'queen', 'king'}

    def __repr__(self):
        return '{} of {}'.format(self.rank, self.suit)

    def bj_value(self):
        if self.is_royal():
            return 10
        elif self.rank == 'ace':
            return 1
        else:
            return int(self.rank)