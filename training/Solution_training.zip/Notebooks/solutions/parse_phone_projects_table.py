import textfsm

raw_text_data = """number       status       project  description
0491 570 157 active       A        used to be in project B
0491 570 158 active       A        
0491 570 159 disconnected A        
0491 570 110 active       B        was disconnected on 2019/12/01 activated again 2019/12/02
0491 570 313 active       B        previously was 0491 573 087
0491 570 737 inactive     B        Deactivated 2019/06/09
0491 571 266 disconnected C        
0491 571 491 disconnected C        
0491 571 804 active       C        
0491 572 549 active       C        
0491 572 665 active       Update   
0491 572 983 inactive     Update   Deactivated 2019/06/01
0491 573 770 disconnected Update   
0491 573 087 disconnected          
"""

# Load in the TextFSM template
with open("phone_info_all.textfsm", mode='rt') as template:
    re_table = textfsm.TextFSM(template)
fsm_results = re_table.ParseText(raw_text_data)
print(fsm_results)