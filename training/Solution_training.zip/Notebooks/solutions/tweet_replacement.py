pattern = r"""
    ^                    # start of the line
    (?P<timestamp>.+):   # any characters up to a :
    (?P<user>\w+):       # the username as a single word
    TWEET:               # literally the word TWEET
    (?P<text>.+)         # text to the end of the line
    $
"""

replacement = '"\g<timestamp>","\g<user>","\g<text>"'

print(re.sub(pattern, replacement, text, flags=re.I | re.M | re.X))
