abalone.plot(kind='hexbin', x='whole weight', y='diameter', gridsize=50)
