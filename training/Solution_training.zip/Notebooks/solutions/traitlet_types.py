class NewFilePath(traitlets.TraitType):
    
    info_text = 'Path to where a new file can be stored - requires a valid directory'
    
    def validate(self, obj, value):
        """
        Check the incoming `value` for the trait.
        
        In this validate function you can cooerce the incoming data to be the required object type.
        
        The `obj` is object which will have the trait.
        """
        base_dir = os.path.dirname(value)
        if not os.path.exists(value) and os.path.exists(base_dir) and os.path.isdir(base_dir):
            return value
        
        # self.error will nicely format an error message.
        self.error(obj, value)


class CurrencyHistory(traitlets.HasTraits):
    
    name = traitlets.Unicode()
    code = traitlets.Unicode()
    output_history = NewFilePath()

    def record_exchange_rate(self):
        url = 'http://data.fixer.io/api/latest'
        params = {
            'access_key': '93136301b1c8a659c34b8ce6bb63d0fa',
            'symbols': self.code,
            'base': 'EUR'
        }
        response = requests.get(url, params)
        response.raise_for_status()
        exchange_rate = response.json()['rates'][self.code]
        with open(self.output_history, 'at') as f:
            f.write(f'{exchange_rate}\n')
        return exchange_rate
    
aud = CurrencyHistory(name="Australian Dollar", code='AUD', output_history='./aud_history.txt')
aud.record_exchange_rate()