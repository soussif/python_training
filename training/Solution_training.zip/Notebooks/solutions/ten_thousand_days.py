print((date.today() - date(1984, 8, 13)).days)
print(date(1984, 8, 13) + timedelta(days=10000))
print(datetime.now().strftime('%-I:%M %p %A %-d %B %Y'))
