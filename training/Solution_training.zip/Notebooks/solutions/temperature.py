params = {
    'appid': "ef29e1f100cb2a25ce2fb9f5816faa5d",
    'q': 'Sydney,AU',
    'units': 'metric'
}
response = requests.get(weather_url, params)
response.raise_for_status()
weather = response.json()
print(weather['main']['temp'])
print(datetime.fromtimestamp(weather['sys']['sunrise']).isoformat())
