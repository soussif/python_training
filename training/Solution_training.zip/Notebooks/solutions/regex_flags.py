
len(re.findall('#PyConAU', text, flags=re.M | re.I))
