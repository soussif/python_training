mushrooms['population'].cat.reorder_categories(
    ['solitary', 'scattered', 'clustered', 'several', 'numerous', 'abundant'],
    ordered=True,
    inplace=True
)

mushrooms.loc[mushrooms['population'] >= 'clustered'].describe()
