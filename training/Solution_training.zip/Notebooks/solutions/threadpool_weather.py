"""This is an example of using concurrent.futures ThreadingPool to query the OpenWeatherMap
API for finding multiple cities weather concurrently."""

import requests
import concurrent.futures

APPID = "ef29e1f100cb2a25ce2fb9f5816faa5d"  # Your key here

# Note: don't put the query data in url, as it is in params
base_url = "http://api.openweathermap.org/data/2.5/weather"


results = {}
jobs = {} # Keep track of futures

def get_weather(city: str) -> float:
    """Fetch weather results for the given city"""
    params = {'q': city, "APPID": APPID, 'units': 'metric'}
    response = requests.get(base_url, params=params)
    current_temperature = response.json()['main']['temp']
    return current_temperature

def url_done(fut) -> None:
    """Callback when the future is done"""
    url = jobs[fut]
    results[url] = fut.result()

cities = ["Melbourne,AU", "Sydney,AU", "Brisbane,AU",
    "Perth,AU", "Adelaide,AU", "Canberra,AU", "Hobart,AU"]

with concurrent.futures.ThreadPoolExecutor(max_workers=5) as exe:
    for city in cities:
        fut = exe.submit(get_weather, city)
        jobs[fut] = city
        fut.add_done_callback(url_done)

print(results)