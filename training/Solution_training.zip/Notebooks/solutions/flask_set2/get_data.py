import requests

# 1. Using the requests library, call your Flask app's convert function from within an IPython Notebook and print out the result.
response = requests.get("http://localhost:5000/convert/1")
print(response.text)

# 2. What happens if you pass invalid parameters (i.e. a string instead of a number for GiB)?
response = requests.get("http://localhost:5000/convert/not_a_number")
print(response.text)
# (try this again when you have completed step 3)
