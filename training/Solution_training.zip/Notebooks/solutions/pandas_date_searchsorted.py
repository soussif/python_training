
public_holidays.sort_values('Date', inplace=True)
today = pd.Timestamp.today()
ix = public_holidays['Date'].searchsorted(today)

print(public_holidays.iloc[ix])

nsw_holidays = public_holidays.loc[public_holidays['Jurisdiction'] == 'nsw']
ix = nsw_holidays['Date'].searchsorted(today)
print(nsw_holidays.iloc[ix])
