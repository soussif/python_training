import pyshark
from collections import defaultdict

my_interface = 'enp5s0'
filtered_cap = pyshark.LiveCapture(my_interface, bpf_filter='tcp and port 443')
filtered_cap.sniff(packet_count=100)

packet_types = defaultdict(int)
packet_sources = defaultdict(int)

for pkt in filtered_cap:
    packet_types[pkt.highest_layer] += 1
    packet_sources[pkt.ip.src] += 1
    
print("Packet count by type")
print("Proto \t Count")
for proto, count in packet_types.items():
    print(proto, "\t", count)
print("Packet count by source addresses")
print("Source \t Count")
for src_addr, count in packet_sources.items():
    print(src_addr, "\t", count)
