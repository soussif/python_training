import pandas as pd

scenes = pd.read_csv(fs.open('s3://landsat-pds/scene_list.gz'), parse_dates=['acquisitionDate'], compression='gzip')
print(len(scenes))
print(scenes['acquisitionDate'].max() - scenes['acquisitionDate'].min())

canberra_scenes = scenes.loc[(scenes['path'] == 90) & (scenes['row'] == 85)]
print(canberra_scenes['acquisitionDate'].max() - canberra_scenes['acquisitionDate'].min())

from PIL import Image
large_thumbs = fs.glob('landsat-pds/c1/L8/090/085/**/*thumb_large.jpg')
large_thumbs.sort()
Image.open(fs.open(large_thumbs[-1]))
