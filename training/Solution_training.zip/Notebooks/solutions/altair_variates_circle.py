x, y = np.random.uniform(size=(2, 1000))
df = pd.DataFrame({'x': x, 'y': y, 'in_circle': x**2 + y**2 < 1})
df.to_json('points.json', orient='records')

# Or this:
# df.to_csv('points.csv')

# For automatic serialization:
# alt.data_transformers.enable('csv')

# For example:

# %%writefile setup.py
# import pandas as pd
# import numpy as np
# import altair as alt
# 
# alt.renderers.enable('notebook')
# alt.data_transformers.enable('csv')

# Then run this:
# %run setup.py

print(len(df))

line_x = np.linspace(0, 1, num=1000)
line_y = np.sqrt(1 - line_x**2)
line_df = pd.DataFrame({'x': line_x, 'y': line_y})

points = alt.Chart(df).mark_circle().encode(
    x='x',
    y='y',
    color='in_circle'
)

line = alt.Chart(line_df).mark_line(color='black').encode(
    x='x',
    y='y'
)

(points + line).interactive()
