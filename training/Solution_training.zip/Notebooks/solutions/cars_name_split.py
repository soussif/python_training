cars = pd.read_csv('Data/Auto.csv', index_col=0)

car_make_model = cars['name'].str.split(n=1, expand=True)
car_make_model.columns = ['make', 'model']

(car_make_model['make'] == 'peugeot').sum()
