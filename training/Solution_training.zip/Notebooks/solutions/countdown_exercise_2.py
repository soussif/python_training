import datetime as dt
import asyncio
import time

async def countdown(n=5):
    for i in range(n, 0, -1):
        print('Time', dt.datetime.now(), 'Down', i)
        await asyncio.sleep(1)

async def main():
    print('Start', dt.datetime.now())
    task1 = asyncio.create_task(countdown(n=5))

    await task1
    
    # This blocks, pausing the above until it's finished:
    import time
    time.sleep(2)

    print('End', dt.datetime.now())

asyncio.run(main())
