from flask import Flask

app = Flask(__name__)

@app.route("/hello")
def hello():
    return "Hello world!"

@app.route("/hello/<username>")
def hello_world(username):
    return 'Hello {}!'.format(username)

@app.route("/convert/<GiB>")
def convert(GiB):
    return "{} GiB is {} bytes".format(GiB, float(GiB) * 1024**3)

@app.route("/")
def index():
    return "Hello world!"

if __name__ == '__main__':
    app.run(debug=True)
