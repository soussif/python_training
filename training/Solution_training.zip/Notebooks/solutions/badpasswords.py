"""
Exercise solution:

Open the `data/500-worst-passwords.txt.bz2` file and list the first 10.
"""

import bz2
from pathlib import Path

data_path = Path('~/Data').expanduser()

data = bz2.BZ2File(data_path / '500-worst-passwords.txt.bz2').read()

lines = data.decode('utf-8').splitlines()

print(lines[:10])
