"""
Exercise: write a decorator map_kwargs that can be applied like this:

@map_kwargs({'hue': 'color', 'colour': 'color'})

to a function like this:

@map_kwargs({'hue': 'color', 'colour': 'color'})
def violinplot(*args, **kwargs):
    assert 'hue' not in kwargs and 'colour' not in kwargs

and have the function:

1. accept only one of the arguments (mutually exclusive)
2. normalize the argument names according to the dictionary mapping (here, to "color")

Solution:
"""

from functools import wraps

def map_kwargs(kwarg_replacements):
    """
    A decorator function to replace old kwarg names with new ones
    """
    
    def decorator(function):
        @wraps(function)
        def inner(*args, **kwargs):
            new_kwargs = {}
            # Ensure either old or new kwarg name is passed, not both,
            # and normalize to the new one
            for old, new in kwarg_replacements.items():
                if old in kwargs and new in kwargs:
                    raise ValueError(f'pass only one of the keyword arguments {old} or {new}')
            # Replace old keys with new
            for key, value in kwargs.items():
                if key in kwarg_replacements.keys():  # i.e. old name
                    # Use the new name as the key instead (with the same value)
                    new_kwargs[kwarg_replacements[key]] = value
                else:
                    new_kwargs[key] = value
            output = function(*args, **new_kwargs)
            return output
        return inner
    return decorator


@map_kwargs({'hue': 'color', 'colour': 'color'})
def violinplot(color=None):
    """
    Do some plotting ...
    ... but for now, just return the color kwarg.
    
    [This docstring should be preserved despite the decorator...]
    """
    return {'color': color}

# Now this fails:
# violinplot(hue='Cylinders', color='Cylinders')

# whereas this normalizes "hue" to "color":
assert violinplot(hue='Cylinders') == {'color': 'Cylinders'}