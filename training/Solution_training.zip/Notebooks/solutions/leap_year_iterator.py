"""
A custom iterator class that is also iterable.
"""

class LeapYearIterator:
    def __init__(self, year, max_year=2020):
        assert year < max_year
        self.year = year
        self.max_year = max_year
   
    # Return the next leap year. Notice it's infinite:
    def __next__(self):
        while True:
            self.year += 1
            if isleap(self.year):
                return self.year
            if self.year > self.max_year:
                raise StopIteration()
    
    # To make ``LeapYearIterator`` iterable, we also define an __iter__
    # method. `LeapYearIterator`` objects are already iterators, so
    # ``iter`` can just return the object itself.
    def __iter__(self):
        return self


# Because __iter__ is defined, you can use a LeapYearIterator object
# in a for loop:
for leap_year in LeapYearIterator(1980):
    print(leap_year)

# You can also implicitly loop over one using `in`:

# Year 2004 is a leap year.
assert 2004 in LeapYearIterator(1890)

# Year 1900 is not a leap year.
assert 1900 not in LeapYearIterator(1890)

# Or you can generate a list of all leap years:
leap_years = list(LeapYearIterator(1980))
assert leap_years == [1984, 1988, 1992, 1996, 2000, 2004, 2008, 2012, 2016, 2020]

