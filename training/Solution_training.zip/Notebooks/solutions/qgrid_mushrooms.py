qgrid.show_grid(mushrooms, show_toolbar=True)
