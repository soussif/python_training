"""
Sending an MMS
"""

# Add imports here
# Define image_url
mms_url = 'https://tapi.telstra.com/v2/messages/mms'

image = requests.get(image_url, proxies=proxies).content

from base64 import b64encode
b64encode(image)[:100]

mms_data1 = {
    'to': your_mobile_number, 
    'subject': 'Subject goes here',
    'from': phone_number,
    'MMSContent': [{'type': 'image/png',
                    'filename': 'image_test.png',
                    'payload': b64encode(image).decode()}],
    'replyRequest': False,
}

response = requests.post(mms_url, json=mms_data1, headers=headers, proxies=proxies)
response.text